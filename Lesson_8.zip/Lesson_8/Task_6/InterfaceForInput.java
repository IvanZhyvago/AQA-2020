package Lesson_8.Task_6;

public interface InterfaceForInput {
    void readData ();
}
