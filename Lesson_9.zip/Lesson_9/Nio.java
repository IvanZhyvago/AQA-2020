package Lesson_9;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Nio {
        Nio () {
        }

        public Path getPath () {
        Path myFile = Paths.get("C:\\Users\\ivan.zhyvago\\IdeaProjects\\AQA_Courses" +
                "\\AQA_Lesson_5\\src\\Lesson_9\\txt.txt");
            return myFile;

    }


        public void writeToFile(String str) throws IOException {
            Files.write (getPath(), str.getBytes());
        }

        public String readFile() throws IOException {
            BufferedReader reader = Files.newBufferedReader(getPath(), StandardCharsets.US_ASCII);
            String forCheckNull;
            String currentLine = null;
            while((forCheckNull = reader.readLine()) != null){
                currentLine = forCheckNull;
            }
            return currentLine;
        }

    public static void main(String[] args) throws IOException {
            Nio nio = new Nio ();
            String question = "Hello world in Nio Class";
            nio.writeToFile (question);
            System.out.println(nio.readFile ());
        }
}
